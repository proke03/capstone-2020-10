﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ItemOnInventory : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    Inventory inventory;
    public Item item;

    void Start()
    {
        inventory = Inventory.Instance;
    }
    
    void Update()
    {
        
    }

    public void OnPointerEnter(PointerEventData eventData)
    {

    }

    public void OnPointerExit(PointerEventData eventData)
    {

    }
}

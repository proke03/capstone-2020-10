﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TempItemChangeModule : CharacterModule {
    public ItemBaseTemp[] items;

    private ToolActionModule toolActionModule;

    int index = 0;

    public override void ModuleAwake() {
        toolActionModule = GetModule<ToolActionModule>();
    }

    public override void ModuleUpdate() {
        if (Input.GetKeyDown(KeyCode.Alpha1)) {
            foreach (var item in items) {
                item.gameObject.SetActive(false);
            }

            items[0].gameObject.SetActive(true);
            toolActionModule.itemOnHand = items[0];
        }
        if (Input.GetKeyDown(KeyCode.Alpha2)) {
            foreach (var item in items) {
                item.gameObject.SetActive(false);
            }

            items[1].gameObject.SetActive(true);
            toolActionModule.itemOnHand = items[1];
        }
    }
}
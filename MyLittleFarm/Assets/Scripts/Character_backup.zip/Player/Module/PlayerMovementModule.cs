﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovementModule : MovementModule {
    public float speed = 4;

    public override void ModuleUpdate() {
        Vector2 characterPosition = controller.transform.position;
        Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        int direction = (mousePosition.x < characterPosition.x) ? -1 : 1;

        var s = controller.transform.localScale;
        s.x = direction * Mathf.Abs(s.x);
        controller.transform.localScale = s;

        var input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));

        currentVelocity = input * speed;
        targetVelocity = input * speed;

        if (Input.GetKeyDown(KeyCode.Space) && controller.zObject.IsGround) {
            controller.zObject.SetVelocity(5);
        }
    }
}
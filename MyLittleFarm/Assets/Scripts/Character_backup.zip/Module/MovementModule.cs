﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementModule : CharacterModule {
    public LayerMask collisionMask;

    /// <summary>
    /// 목표 속도
    /// </summary>
    [System.NonSerialized] public Vector2 targetVelocity;

    /// <summary>
    /// 목표 속도를 목표로 계산된 속도
    /// </summary>
    [System.NonSerialized] public Vector2 currentVelocity;

    private RayCollider2D rayCollider;

    public override void ModuleAwake() {
        rayCollider.UpdateSpacing(controller.collider.bounds);
    }

    private Vector2 tempVelocity;
    public float smoothTime = 0;

    public override void ModuleFixedUpdate() {
        currentVelocity = Vector2.SmoothDamp(currentVelocity, targetVelocity, ref tempVelocity, smoothTime);
        Process(currentVelocity * Time.deltaTime);
    }

    protected void Process(Vector2 velocity) {
        rayCollider.UpdateOrigins(controller.collider.bounds);

        VerticalCollisionTest(ref velocity);
        HorizontalCollisionTest(ref velocity);

        var pos = controller.transform.position + (Vector3)velocity;
        pos.z = pos.y;
        controller.transform.position = pos;
    }

    /// <summary>
    /// 세로 충돌 처리 함수
    /// </summary>
    protected void VerticalCollisionTest(ref Vector2 velocity) {
        int direction = System.Math.Sign(velocity.y);
        float length = Mathf.Abs(velocity.y);

        for (int i = 0; i < rayCollider.verticalCount; i++) {
            var origin = (direction == -1 ? rayCollider.bottomLeftOrigin : rayCollider.topLeftOrigin) + Vector2.right * rayCollider.verticalSpacing * i;

            var hit = Physics2D.Raycast(origin, Vector2.up * direction, length, collisionMask);
            if (hit) {
                velocity.y = (hit.distance - RayCollider2D.skinWidth) * direction;
                length = hit.distance;
            }

            Debug.DrawRay(origin + velocity, Vector2.up * direction * length, hit ? Color.green : Color.red);
        }

    }

    /// <summary>
    /// 가로 충돌 처리 함수
    /// </summary>
    protected void HorizontalCollisionTest(ref Vector2 velocity) {
        int direction = System.Math.Sign(velocity.x);
        float length = Mathf.Abs(velocity.x);

        for (int i = 0; i < rayCollider.horizontalCount; i++) {
            var origin = (direction == -1 ? rayCollider.bottomLeftOrigin : rayCollider.bottomRightOrigin) + Vector2.up * rayCollider.horizontalSpacing * i;

            var hit = Physics2D.Raycast(origin, Vector2.right * direction, length, collisionMask);
            if (hit) {
                velocity.x = (hit.distance - RayCollider2D.skinWidth) * direction;
                length = hit.distance;
            }

            Debug.DrawRay(origin + velocity, Vector2.right * direction * length, Color.red);
        }
    }
}
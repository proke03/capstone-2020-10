﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(ZObject))]
public class CharacterController2D : MonoBehaviour {
    [System.NonSerialized] public List<CharacterModule> moduleList = new List<CharacterModule>();
    [System.NonSerialized] public new Rigidbody2D rigidbody;
    [System.NonSerialized] public new BoxCollider2D collider;

    [System.NonSerialized] public ZObject zObject;

    private void Awake() {
        zObject = GetComponent<ZObject>();
        rigidbody = GetComponent<Rigidbody2D>();
        collider = transform.Find("Collider").GetComponent<BoxCollider2D>();

        var modules = GetComponents<CharacterModule>();
        foreach (var module in modules) {
            moduleList.Add(module);
            module.controller = this;
        }

        foreach (var module in moduleList) {
            if (module.isEnabled)
                module.ModuleAwake();
        }
    }

    private void Start() {
        foreach (var module in moduleList) {
            if (module.isEnabled)
                module.ModuleStart();
        }
    }

    private void Update() {
        foreach (var module in moduleList) {
            if (module.isEnabled)
                module.ModuleUpdate();
        }
    }

    private void FixedUpdate() {
        foreach (var module in moduleList) {
            if (module.isEnabled)
                module.ModuleFixedUpdate();
        }
    }
}
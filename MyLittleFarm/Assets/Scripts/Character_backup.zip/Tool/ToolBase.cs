﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class ToolBase : ItemBaseTemp {
    //public ToolData data;
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New ToolData", menuName = "GameData/Create ToolData", order = 1)]
public class ToolData : ItemData {

}